﻿using System;
using System.Collections.Generic;

namespace Milestone1_feb13_RK.Models;

public partial class Student
{
    public int StudentId { get; set; }

    public string? StudentName { get; set; }

    public int? Age { get; set; }


    public string? Branch { get; set; }
}
