﻿using System;
using System.Collections.Generic;

namespace Milestone1_feb13_RK.Models;
// it will create getters and setters for entities
public partial class Author
{
    public int AuthorId { get; set; }

    public string? AuthorName { get; set; }
}
