﻿using System;
using System.Collections.Generic;

namespace Milestone1_feb13_RK.Models;

//it will create getters and setters for entities
public partial class Book
{
    public int BookId { get; set; }

    public string? BookName { get; set; }

    public int AuthorId { get; set; }

    public string? AuthorName { get; set; }
}
